# UTS Kecerdasan Buatan
Repositori ini berisi tugas UTS mata kuliah Kecerdasan Buatan.

## Struktur:
- soal_1.txt
- soal_2_review_jurnal_terperinci.pdf
- Data Pendukung/soal1.py
