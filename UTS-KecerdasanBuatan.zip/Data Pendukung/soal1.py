# soal1.py
# Program sederhana untuk menyelesaikan tugas soal 1 UTS Kecerdasan Buatan

print("Hello, ini jawaban soal 1!")
